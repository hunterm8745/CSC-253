﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_Class
{
    public class _Area
    { 
        static double Calc_Area(double radius)
        {
            double area = Math.PI * Math.Pow(radius, 2);

            return area;
        }

        static double Calc_Area(double width, double length)
        {
            double area = width * width;

            return area;
        }

        static double Calc_Area(double radius, double height)
        {
            double area = (2 * Math.PI * Math.Pow(radius, 2)) + (height * (2 * Math.PI * radius));

            return area;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
