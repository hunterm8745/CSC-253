﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Charges
{
    class Program
    {
        static double CalcStayCharges(int days)
        {
            int stay = 0;
            int charge = 350;

            stay = days * charge;

            return stay;
        }

        static double CalcMiscCharges(double meds, double surg, double lab, double phyReh)
        {
            double misc = meds + surg + lab + phyReh;

            return misc;
        }

        static double CalcTotalCharges(double stay, double misc)
        {
            double total = stay + misc;

            return total;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Days Spent in Hospital: ");
            int days = Int32.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Medication Cost:");
            double meds = Double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Surgical Cost:");
            double surg = Double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Lab Cost:");
            double lab = Double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Physical Rehabilitation Cost:");
            double phyReh = Double.Parse(Console.ReadLine());
            Console.WriteLine();

            double stay = CalcStayCharges(days);
            double misc = CalcMiscCharges(meds, surg, lab, phyReh);
            double total = CalcTotalCharges(stay, misc);

            Console.WriteLine();
            Console.WriteLine($"Cost for Hospital Stay: ${stay}");
            Console.WriteLine($"Cost for Misc Charges: ${misc}");
            Console.WriteLine($"Total Cost for Hospital Visit: ${total}");

            Console.ReadLine();
        }
    }
}
